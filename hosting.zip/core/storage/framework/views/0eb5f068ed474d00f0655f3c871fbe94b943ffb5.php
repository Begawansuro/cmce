<?php $__env->startSection('js'); ?>

<script type="text/javascript">
  $(document).ready(function() {
    $('#tab-ser').DataTable({
      "iDisplayLength": 10
    });
} );
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
 <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Data Karyawan Rekanan</strong>
 <button type="button" class="col-md-1 btn btn-outline-secondary btn-sm float-right"><i class="ti-filter"></i>&nbsp; Find</button>
 <a href="<?php echo e(route('karyawan.create')); ?>" class="col-md-1 btn btn-outline-primary btn-sm float-right">
 <i class="ti-plus"></i>&nbsp; Add</a>
                        </div>
                        <div class="card-body">
                  <table id="tab-ser" class="table table-striped table-bordered">
                    <thead>
                      <tr>
                        <th>Photo</th>
                        <th>NIK</th>
                        <th>Nama</th>
                        <th>Gender</th>
                        <th>Dept / Devisi</th>
                        <th>Jabatan</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
					  <td>
					  <?php if($data->photo): ?>
							<img class="user-avatar rounded-circle" src="<?php echo e($data->photo); ?>" alt="User Avatar" style="width:60px;height:60px">
                          <?php else: ?>
							<img class="user-avatar rounded-circle" src="<?php echo e(url('images/default.png')); ?>" alt="User Avatar" style="width:60px;height:60px">
                          <?php endif; ?>
						  
					  </td>
						<td><?php echo e($data->nik); ?></td>
						  <td><?php echo e($data->namakaryawan); ?></td>
						  <td><?php echo e($data->gender); ?></td>
						  <td><?php echo e($data->dept_desc); ?> / <?php echo e($data->line_desc); ?></td>
						  <td><?php echo e($data->jabatan_desc); ?></td>
                      </tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                        </div>
                    </div>
                </div>
				
	 			
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>