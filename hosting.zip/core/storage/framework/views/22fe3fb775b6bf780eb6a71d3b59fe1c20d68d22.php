<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document).ready(function() {
    $('#tab-per').DataTable({
      "iDisplayLength": 10
    });

} );
</script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
 <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Data Perusahaan Rekanan</strong>
 <button type="button" class="col-md-1 btn btn-outline-secondary btn-sm float-right"><i class="ti-filter"></i>&nbsp; Find</button>
 <a href="<?php echo e(route('perusahaan.create')); ?>" class="col-md-1 btn btn-outline-primary btn-sm float-right">
 <i class="ti-plus"></i>&nbsp; Add</a>
                        </div>
                        <div class="card-body">
                  <table id="tab-per" class="table table-striped table-bordered">
                    <thead>
                      <tr>
                        <th>NPWP</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                      </tr>
                    </thead>
                    <tbody>
					<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
					  <td>
                            <?php echo e($data->npwp); ?>

                          </td>
						  <td>
                            <?php echo e($data->nama); ?>

                          </td>
						  <td>
                            <?php echo e($data->adr); ?>

                          </td>
                      </tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>