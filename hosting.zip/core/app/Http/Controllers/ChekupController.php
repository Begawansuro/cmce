<?php

namespace App\Http\Controllers;

use App\Chekup;
use Illuminate\Http\Request;

class ChekupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Chekup  $chekup
     * @return \Illuminate\Http\Response
     */
    public function show(Chekup $chekup)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Chekup  $chekup
     * @return \Illuminate\Http\Response
     */
    public function edit(Chekup $chekup)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Chekup  $chekup
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Chekup $chekup)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Chekup  $chekup
     * @return \Illuminate\Http\Response
     */
    public function destroy(Chekup $chekup)
    {
        //
    }
}
