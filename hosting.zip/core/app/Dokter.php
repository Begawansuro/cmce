<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dokter extends Model
{
   protected $table = 'mc_dokter';
}
